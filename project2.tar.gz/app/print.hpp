#ifndef PRINT_HPP
#define PRINT_HPP

#include <iostream>
#include <sstream>
#include <string>
#include "student.hpp"
#include "get_input.hpp"

void print_total(student* students, unsigned int number_students);

void print_cutpoint(student* students,cutpoint current_cutpoint,unsigned number_students);

#endif