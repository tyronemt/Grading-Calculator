#ifndef STUDENT_HPP
#define STUDENT_HPP

#include <iostream>
#include <sstream>
#include <string>
#include "get_input.hpp"

struct student
{
    unsigned int id;
    char grade_option;
    std::string name;
    unsigned int* raw_score = 0;
    double total;
};

student* input_into_array(unsigned int size);

void student_raw_scores(student* students,unsigned int number_students,unsigned int size);

void calculate_total(student* students, unsigned int* points_possible, unsigned int* weight,
	unsigned int number_students,unsigned int number_raw_scores);

void Zeros(student* students,unsigned number_students, unsigned number_of_artifacts);

char calculate_grade(double total,cutpoint cutpoints);

#endif