#include "student.hpp"

// Create a Student struct using the id, grade option, and name
student student_input_structure()
{
	student i;
	std::cin >> i.id >> i.grade_option;
	std::cin.ignore(1);
	std::getline(std::cin,i.name);
	return i;
}

//put each student into an array for easy access
student* input_into_array(unsigned int size)
{
	student* arr = new student[size];
	for (int i=0; i < size; i++)
	{
		arr[i] = student_input_structure();
	}
    return arr;
}

//Used to put zeros for the raw score if no raw score was provided for the student
void Zeros(student* students,unsigned number_students, unsigned number_of_artifacts)
{
	unsigned int* arr = new unsigned int[number_of_artifacts];
	for (int a=0; a < number_students; a++)
	{
		if (students[a].raw_score == 0)
		{
			for (int i=0; i < number_of_artifacts; i++)
			{
				arr[i] = 0;
			}
			students[a].raw_score = arr;
		}	
	}
	delete [] arr;
}

//See if a raw score is provided for each student and set the member raw score from the Student 
//Structure to the raw scores
void student_raw_scores(student* students,unsigned int number_students,unsigned int size)
{
	unsigned int* ar = new unsigned int[size];
	std::string line;
	std::getline(std::cin,line);
	std::stringstream in(line);
	std::string id;
	in >> id;
	unsigned int id_number = std::stoi(id);
	unsigned int x = 0;
	std::string t;
	while(x < size)
    {
        in >> t;
        ar[x] = std::stoi(t);
        x++;
    }
    for (int z=0; z < number_students; z++)
	{
		if (students[z].id == id_number)
		{
			students[z].raw_score = ar;
		}	
	}

}
//Calculate the total and puts it in the total member for the Student Structure
void calculate_total(student* students, unsigned int* points_possible, unsigned int* weight,
	unsigned int number_students,unsigned int number_raw_scores)
{
	double sum;
	double outcome;
	for (int z=0; z < number_students; z++)
	{
		sum = 0;
		for (int i=0; i < number_raw_scores; i++)
		{
			outcome = (students[z].raw_score[i]/(double)points_possible[i]);
			sum = (outcome * weight[i]) + sum;
		}
		students[z].total = sum;
		delete [] students[z].raw_score;
	}
}
// Puts the final grade into the grade member for the student structure
char calculate_grade(double total,cutpoint cutpoints)
{
	if (total >= cutpoints.a)
	{
		return 'A';
	}
	else if (total >= cutpoints.b)
	{
		return 'B';
	}
	else if (total >= cutpoints.c)
	{
		return 'C';
	}
	else if (total >= cutpoints.d)
	{
		return 'D';
	}
	else
	{
		return 'F';
	}
}