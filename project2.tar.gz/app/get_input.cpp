#include "get_input.hpp"

//Get single unsigned int input
unsigned int get_user_number()
{
	unsigned int i;
	std::cin >> i;
	std::cin.ignore(1);

	return i;
}

//Gets the whole line and put it in an array based on the spaces
unsigned int* get_line(const unsigned int& size)
{
	unsigned int* arr = new unsigned int[size];

	std::string input_line;
	std::getline(std::cin,input_line);

	std::stringstream in(input_line);

	unsigned int i = 0;
	while(i < size)
    {
        in >> arr[i];
        i++;
    }

    return arr;
}


// Creates a cutpoint structure for the cutpoints
cutpoint get_cutpoint()
{
	cutpoint i;

	std::cin >> i.a >> i.b >> i.c >> i.d;

	return i;
}
