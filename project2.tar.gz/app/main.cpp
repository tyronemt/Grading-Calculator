#include <iostream>
#include "get_input.hpp"
#include "student.hpp"
#include "print.hpp"

int main()
{
	//Gets the number of grading artifacts
	unsigned int number_of_artifacts = get_user_number();

	//Gets the whole line of input and puts it in an array that represents the maximum 
	//points possible for each grading assignment
	unsigned int* points_possible = get_line(number_of_artifacts);

	//Gets the whole line of input and puts it in an array that represents the weight
	//of each assginment
	unsigned int* weight = get_line(number_of_artifacts);

	//Gets the total number of students and makes a student structure out of the student
	unsigned int number_students = get_user_number();
	student* students = input_into_array(number_students);

	//Gets the amount of raw scores that will be provided
	unsigned int number_raw_scores = get_user_number();

	//Puts the line of raw scores into an array into the designated student structure
	for (int i=0; i < number_raw_scores; i++)
	{
		student_raw_scores(students,number_students,number_of_artifacts);
	}

	//If there is no raw score provided then the raw score is set as 0
	Zeros(students,number_students,number_of_artifacts);

	//Using the weight and total points possible calculate the total score
	calculate_total(students,points_possible,weight,number_students,number_of_artifacts);

	//Print the total score
	print_total(students, number_students);

	//Get the number of cutpoints 
	unsigned int number_cutpoints = get_user_number();

	//Print out the grade given the cutpoints provided
	cutpoint current_cutpoint;
	for (int i=1; i <= number_cutpoints; i++)
	{
		current_cutpoint = get_cutpoint();
		std::cout << "CUTPOINT SET " << i << std::endl;
		print_cutpoint(students,current_cutpoint,number_students);
	}

	//deallocate the points possible, weight, and the array of students
	delete[] points_possible;
	delete[] weight;
	delete[] students;

}

