#include "print.hpp"

//Used to print the total scores of each student
void print_total(student* students, unsigned int number_students)
{
	std::cout << "TOTAL SCORES" << std::endl;
	for (int i=0; i < number_students; i++)
	{
		std::cout << students[i].id << " " << students[i].name << " " << students[i].total << std::endl;
	}
}

//Print the grade of each student using the cutpoint
void print_cutpoint(student* students,cutpoint current_cutpoint,unsigned number_students)
{
	for (int i=0; i < number_students; i++)
	{
		if (students[i].grade_option == 'G')
		{
			std::cout << students[i].id << " " << students[i].name << " " 
			<< calculate_grade(students[i].total,current_cutpoint) << std::endl;
		}
		else
		{
			if (calculate_grade(students[i].total,current_cutpoint) == 'A' || 
				calculate_grade(students[i].total,current_cutpoint) == 'B' || 
				calculate_grade(students[i].total,current_cutpoint) == 'C')
			{
				std::cout << students[i].id << " " << students[i].name << " P" << std::endl;
			}
			else
			{
				std::cout << students[i].id << " " << students[i].name << " NP" << std::endl;
			}
			
		}
	}
}