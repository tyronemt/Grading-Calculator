#ifndef GET_INPUT_HPP
#define GET_INPUT_HPP

#include <iostream>
#include <sstream>
#include <string>

struct cutpoint
{
	double a;
	double b;
	double c;
	double d;
};

unsigned int get_user_number();
unsigned int* get_line(const unsigned int& size);
cutpoint get_cutpoint();
#endif